# dashkit

A build-your-own dashboard kit. A dashboard is a JSON document: a flat list of widgets, each placed on a 12-column grid of 48px rows (`layout: { x, y, w, h }`) and bound to metrics by key. You change it only through typed operations, so the editor UI, your code and an AI model all use the same path and share one undo history. The host supplies two small adapters, a `DataSource` (catalog plus numbers) and a `Store` (persistence). dashkit supplies the rest:

| Entry point | What it holds | Runs in |
| --- | --- | --- |
| `dashkit/core` | Document schema, ops (`apply`, `applyAll`), layout engine, validation, history, migrations, `summarize`, `diff` | Anywhere (only needs zod) |
| `dashkit/react` | Widget registry, 12 built-in widgets, `DashboardRenderer` and `DashboardEditor` (on react-grid-layout), theme | React 19 |
| `dashkit/ai` | Tool definitions for OpenAI, Anthropic or plain JSON Schema, `applyToolCall`, `systemPromptFragment`, `generateFromBrief` | Anywhere |
| `dashkit/adapters` | `DataSource` / `Store` interfaces, memory and mock adapters, fetch adapters for the reference routes | Anywhere |

Also exported: `dashkit/adapters/contract` (vitest suites for your adapters), `dashkit/styles.css` (the compiled stylesheet) and `dashkit/schema.json`.

## Install

Peer dependencies (install them in the host app):

```sh
npm install react@^19 react-dom@^19 recharts@^2.15 "zod@>=3.25 <4"
# optional, only for dashkit/adapters/contract:
npm install -D vitest
```

recharts 2 depends on an older `react-is`. On React 19.2 or newer, override it to your React version, or charts fail to render:

```jsonc
// package.json
"overrides": { "recharts": { "react-is": "19.2.0" } } // your exact react version
```

dashkit installs its own runtime dependencies: `react-grid-layout`, `tailwind-merge`, `tailwind-variants`, `clsx`, `@radix-ui/react-slot` and `zod-to-json-schema`.

dashkit is not on npm. Depend on it from a local checkout or from git, in the host's `package.json`:

```jsonc
// a local checkout (run `npm run build` in it first, and again after pulling changes)
"dashkit": "file:../dashkit"
// or git (dashkit's `prepare` script builds dist/ during install)
"dashkit": "git+https://github.com/<owner>/dashkit.git#v0.3.0"
```

`file:` symlinks the checkout, so a bundler can pick up dashkit's own dev copies of React or zod from `../dashkit/node_modules`. If you see "Invalid hook call" or zod errors about mismatched instances, install a tarball instead: `npm pack` in dashkit, then `npm install ../dashkit/dashkit-0.3.0.tgz` in the host.

Import the stylesheet once. It is compiled from Tailwind 4 with every class prefixed `dk:` and without Tailwind's preflight reset, so the host needs no Tailwind and nothing in it restyles the host page. Next.js also needs the package in `transpilePackages`:

```js
// next.config.mjs
export default { transpilePackages: ['dashkit'] };
```

```ts
// app/layout.tsx (or any root module)
import 'dashkit/styles.css';
```

The stylesheet names Inter and Bricolage Grotesque in `--dk-font` / `--dk-font-display` but does not load them. Load them yourself or point the variables at your own fonts (see [Theme](#theme)).

## Quick start

Render a dashboard with fake data:

```tsx
import 'dashkit/styles.css';
import { applyAll, createDashboard, type Catalog } from 'dashkit/core';
import { DashboardDataProvider, DashboardRenderer, builtinWidgets, createRegistry } from 'dashkit/react';
import { createMockDataSource } from 'dashkit/adapters';

const catalog: Catalog = {
  metrics: [{ key: 'revenue', label: 'Revenue', unit: 'USD', format: 'currency', dimensions: ['day'] }],
  dimensions: [{ key: 'day', label: 'Day' }],
  windows: [{ preset: 'last_30d', label: 'Last 30 days' }],
};
const registry = createRegistry(builtinWidgets);
const dataSource = createMockDataSource(catalog);
const last30 = { preset: 'last_30d' };
const doc = applyAll(createDashboard({ title: 'Sales' }), [
  { op: 'addWidget', widget: { id: 'h', type: 'heading', title: 'Sales', data: { level: 1 } } },
  { op: 'addWidget', after: 'h', widget: { id: 'rev', type: 'kpi', title: 'Revenue', bindings: { value: { metric: 'revenue', window: last30, compare: 'previous' } } } },
  { op: 'addWidget', after: 'rev', widget: { type: 'trend', title: 'Revenue by day', size: { w: 9, h: 6 }, bindings: { series: { metric: 'revenue', by: 'day', window: last30 } } } },
], { registry, author: 'code' });

export function SalesDashboard() {
  return (
    <DashboardDataProvider dataSource={dataSource} registry={registry}>
      <DashboardRenderer doc={doc} registry={registry} catalog={catalog} />
    </DashboardDataProvider>
  );
}
```

`DashboardDataProvider` batches every widget's bindings into one `dataSource.resolve` call and caches the slots (`ttlMs`, default 60 s). With `catalog`, the renderer validates each widget and draws an error frame for invalid ones. Pass `mode="edit"` to also show hidden widgets (dimmed, in their stored place).

### Layout

`addWidget` places a widget by `at: { x, y }` if given; otherwise by `after: widgetId` (to the right of that widget when it fits in the row and those cells are free, else at `x = 0` below the tallest widget sharing that widget's rows); otherwise at `x = 0` below the lowest widget. `size: { w, h }` defaults to the type's `defaultSize`. `moveWidget`, `resizeWidget` and `setLayout` rearrange. Every op returns a normalized layout: overlaps are pushed down, then everything compacts upward, the same algorithm react-grid-layout uses, so a stored document renders exactly as stored.

The renderer is react-grid-layout in static mode: 12 columns from 768px of container width (the stored layout), 6 columns from 480px and 1 column below; the 6- and 1-column layouts are generated and never stored. Rows are 48px with 16px gaps (`theme.density: 'compact'` gives 12px).

- The renderer's root `.dk-root` is `width: 100%` and measures itself, so its parent must give it a definite width. Until it is measured the grid renders an empty placeholder of its desktop height; pass `width` to render immediately (tests, SSR).
- Each widget fills its cell, so a `Frame` must fill its height (`height: 100%`).
- Sections are `heading` widgets: `title` is the heading text, `data.level` 1 (24px), 2 (20px, default) or 3 (16px), and `data.description` a muted line under it. Use a level-1 heading at the top as the page title; dashkit renders no page header of its own. A level-1 heading is vertically centred in its cell; levels 2 and 3 sit at the bottom, next to the widgets they title.
- Each widget frame shows a window badge next to its title (`Last 7 days · all clients`, from `windowBadge(widget, catalog)`), shortened to `7d · all` in cards under 260px and hidden under 200px.

## Editor

`DashboardEditor` is a full editor: toolbar (undo, redo, save, JSON view), an icon palette rail, the grid canvas and a property panel generated from each widget's `form`. It brings its own `DashboardDataProvider`.

- Drag a widget to move it and its corner handle to resize it; each gesture is one `setLayout` op, so one undo step. Click a palette tile to add that widget below the selected one (or at the bottom), or drag the tile onto a cell.
- The selected widget gets an accent ring, a type and size tag (`Trend · 8 × 7`) and a floating duplicate/hide/remove toolbar. Arrow keys move it one cell; Shift+arrows resize it.
- The property panel groups Layout (title, S/M/L/Full size presets, W/H steppers, X/Y nudges), Data (binding pickers) and Appearance (the widget's `form`), with a chart-type control for `trend` and `bar`.
- Editing needs room: when the editor's container is narrower than 1024px (the editor measures its own width, not the window), it keeps its toolbar and shows the dashboard read-only with the notice "Editing needs a wider window".

```tsx
import { useRef, useState } from 'react';
import type { Catalog, Dashboard } from 'dashkit/core';
import type { DataSource, Store } from 'dashkit/adapters';
import {
  BriefingContext,
  DashboardEditor,
  builtinWidgets,
  createRegistry,
  type ButtonProps,
  type DashboardEditorApi,
} from 'dashkit/react';

const registry = createRegistry(builtinWidgets);

function MyButton({ variant, className, type = 'button', ...rest }: ButtonProps) {
  const classes = ['btn', variant === 'primary' && 'btn-primary', className].filter(Boolean).join(' ');
  return <button type={type} className={classes} {...rest} />;
}

export function EditDashboard(props: { initial: Dashboard; catalog: Catalog; dataSource: DataSource; store: Store; ask(prompt: string): void }) {
  const [doc, setDoc] = useState(props.initial);
  const apiRef = useRef<DashboardEditorApi>(null);
  return (
    <BriefingContext.Provider value={{ onAsk: props.ask }}>
      <DashboardEditor
        doc={doc}
        registry={registry}
        catalog={props.catalog}
        dataSource={props.dataSource}
        onChange={setDoc}
        onSave={async (d) => {
          await props.store.save(d);
        }}
        apiRef={apiRef}
        components={{ Button: MyButton }}
      />
    </BriefingContext.Provider>
  );
}
```

| Prop | |
| --- | --- |
| `doc`, `registry`, `catalog`, `dataSource` | Required. A new `doc.id` starts a fresh history. A changed `doc` with the same id replaces the editor's copy unless it has unsaved edits. If you feed the saved document back in, return it as sent (only `meta.updatedAt` may differ, and that difference is ignored); any other change counts as a new document and clears undo history. |
| `onChange(doc)` | After every op, undo and redo. |
| `onSave(doc)` | Shows the Save button; the editor is marked clean once it resolves. |
| `apiRef` | Filled with `DashboardEditorApi`: `getDoc`, `apply(op, author?)`, `applyAll(ops, author?)`, `undo`, `redo`, `markSaved`, `select`. Ops applied here go through the editor's history (undoable, mark it dirty). They never throw: a rejected batch leaves the doc unchanged and shows the reason in the toolbar. |
| `components` | Swap any primitive for your design system: `Frame` (widget card, `WidgetFrameProps`), `Button`, `Menu`, `Input`, `Select`, `Icon`, and `Markdown` (used by the `text` widget; without it text renders as plain preformatted text). The same object works on `DashboardRenderer` and `ComponentsProvider`. Pass a stable object (module-level or memoised): switching it between `undefined` and an object remounts the whole widget tree. |
| `className` | Added to the editor's `.dk-root`. |

A custom `Frame` must render `title`, `meta` (the window badge, after the title), `menu` and `children`, honour `state` (`loading`, `ready`, `empty`, `error`) and `error`, and fill its cell's height. Make it a CSS size container (`container-type: inline-size`, or the `dk:@container` class) so the badge and the widgets' container queries measure the card. The editor's selection chrome and drag surface sit on the grid item around the frame, so a custom frame needs nothing for editing. `heading` widgets render without a frame.

`BriefingContext` is optional: when you provide `onAsk`, `briefing` widgets with a `prompt` show an "Ask about this" button that calls it (use it to open your assistant).

### Composing the editor yourself

`DashboardEditor` is `Toolbar`, `Palette`, `Canvas` (or `JsonView`) and `PropertyPanel` inside an `EditorProvider`, which takes the state from `useDashboardEditor`. Render them yourself to change the arrangement. Palette drags are plain HTML drag-and-drop carrying `PALETTE_DRAG_MIME`, so the palette and the canvas need no shared drag-and-drop scope; both only need the `EditorProvider`.

```tsx
import { Canvas, DashboardDataProvider, EditorProvider, Palette, PropertyPanel, Toolbar, useDashboardEditor } from 'dashkit/react';

function MyEditor({ doc, registry, catalog, dataSource }: Props) {
  const editor = useDashboardEditor(doc, { registry, catalog });
  return (
    <DashboardDataProvider dataSource={dataSource} registry={registry}>
      <EditorProvider editor={editor} registry={registry} catalog={catalog}>
        <div className="dk-root my-editor">
          <Toolbar />
          <Palette />
          <Canvas />
          <PropertyPanel />
        </div>
      </EditorProvider>
    </DashboardDataProvider>
  );
}
```

## Host adapters

```ts
import type { Binding, Catalog, Dashboard, ResolvedSlot } from 'dashkit/core';
import type { DashboardSummary } from 'dashkit/adapters';

type SlotShape = 'value' | 'series' | 'table';

interface DataSource {
  catalog(): Promise<Catalog>;
  /**
   * Resolve each binding to a slot, in order. `shapes`, when given, has the
   * same length and order as `bindings` and says which shape the requesting
   * widget slot expects (e.g. `'table'` for a breakdown table).
   * A binding that fails on its own resolves to `null` at its index.
   */
  resolve(bindings: Binding[], shapes?: SlotShape[]): Promise<Array<ResolvedSlot | null>>;
}

interface Store {
  list(): Promise<DashboardSummary[]>; // { id, title, updatedAt }, newest first
  load(id: string): Promise<Dashboard>;
  save(doc: Dashboard): Promise<Dashboard>;
  remove(id: string): Promise<void>;
}
```

One `resolve` call carries every binding on screen, so a single bad binding must not fail the request. Catch errors per binding on the backend and return `null` at that index: only that widget shows "Data source returned no data for this binding" and the rest render. Reject (or return non-2xx) only when the whole request fails; then every widget in the batch shows the error.

A `Catalog` lists `metrics` (`key`, `label`, `format`: `integer | currency | percentage | decimal | compact`, optional `unit`, `description`, `aggregation`, and `polarity`: `higher_is_better` (default) or `lower_is_better`, which colours a falling cost as good news), `dimensions` (`key`, `label`, optional async `values`) and `windows` (`preset`, `label`). A binding without `by` resolves to a `value` slot (`value`, optional `previous` when `compare: 'previous'`); with `by` to a `series` slot (`points: [{ label, value, previous? }]`); with shape `'table'` to a `table` slot (`columns`, `rows`). Value and series slots carry `format`, optional `unit` and optional `polarity` (copy it from the catalog metric). `CatalogSchema` and `ResolvedSlotSchema` in `dashkit/core` define these exactly.

If your API follows the reference routes, use the fetch adapters:

| Route | Body / response |
| --- | --- |
| `GET {base}/dashboards` | → `{ items: DashboardSummary[] }` |
| `GET {base}/dashboards/:id` | → `Dashboard` |
| `PUT {base}/dashboards/:id` | `Dashboard` → `Dashboard` |
| `DELETE {base}/dashboards/:id` | → empty or any JSON |
| `GET {base}/dashboards/catalog` | → `Catalog` |
| `POST {base}/dashboards/resolve` | `{ bindings, shapes }` → `{ slots: (ResolvedSlot \| null)[] }` |

In routers that match in declaration order (FastAPI, Express), declare `GET /dashboards/catalog` and `POST /dashboards/resolve` before `/dashboards/{id}`, or `catalog` is captured as an id.

```ts
import { createFetchDataSource, createFetchStore } from 'dashkit/adapters';

const authedFetch: typeof fetch = (input, init) =>
  fetch(input, { ...init, credentials: 'include', headers: { ...init?.headers, 'X-Client': 'web' } });

export const dataSource = createFetchDataSource('/api', authedFetch);
export const store = createFetchStore('/api', authedFetch);
```

Non-2xx responses reject with `DashkitError` code `HTTP_<status>`; network failures with `NETWORK`; unparseable bodies with `BAD_RESPONSE`. `createMemoryStore(initialDocs?)` and `createMockDataSource(catalog, { seed?, points? })` cover tests and demos.

Check your own adapters against the same contract the built-ins pass:

```ts
// my-adapters.test.ts
import { runDataSourceContract, runStoreContract } from 'dashkit/adapters/contract';
import { createFetchDataSource } from 'dashkit/adapters';
import { catalog } from './catalog';
import { createSqlStore, emptyTestDatabase } from './sql-store';

runStoreContract('sql store', () => createSqlStore(emptyTestDatabase()));
runDataSourceContract('api data source', () => createFetchDataSource('http://localhost:8000/api'), catalog);
```

The store factory must return a fresh, empty store each call. The data-source suite needs at least one metric with a dimension.

## Theme

Everything renders inside a `.dk-root` element and reads these CSS variables (`DK_VARS` exports the list):

| Group | Variables |
| --- | --- |
| Surfaces and text | `--dk-bg`, `--dk-card`, `--dk-fg`, `--dk-body`, `--dk-muted`, `--dk-subtle`, `--dk-border`, `--dk-border-strong`, `--dk-table-head` |
| Accent | `--dk-accent`, `--dk-accent-tint`, `--dk-accent-pale`, `--dk-accent-fg` |
| Status | `--dk-success`, `--dk-success-bg`, `--dk-danger`, `--dk-danger-bg`, `--dk-warning`, `--dk-warning-bg`, `--dk-info` |
| Charts | `--dk-chart-1`, `--dk-chart-2`, `--dk-chart-3`, `--dk-chart-4` |
| Shape and type | `--dk-radius`, `--dk-shadow`, `--dk-shadow-pop`, `--dk-font`, `--dk-font-display` |

The variables are the only way to theme dashkit: every colour, radius, shadow and font in the compiled utilities reads one of them, and Tailwind's own palette is not in the stylesheet. Defaults are Birdy's palette (`--dk-chart-1` … `--dk-chart-4` are `#5B3FD6`, `#2E9E8F`, `#E0920A`, `#98989E`, checked for colour-blind separation).

How to override:

- Target `.dk-root` with an unlayered rule. The defaults sit on `:where(.dk-root)`, which has zero specificity, so any `.dk-root { … }` rule wins whichever stylesheet loads first.
- A rule inside a cascade `@layer` (for example Tailwind's `@layer base` in your own CSS) loses to the unlayered defaults. Keep the override outside any layer.
- Variables set on `:root` or `body` do not reach dashkit, because `.dk-root` declares its own values. Map them onto `.dk-root` instead: `.dk-root { --dk-accent: var(--brand); }`.

`createTheme(vars, selector = '.dk-root')` returns such a rule; unknown names and values containing `; { } < >` are dropped. Map your own tokens onto it, for example Birdy's:

```tsx
import { createTheme } from 'dashkit/react';

const DASHKIT_THEME = createTheme({
  '--dk-bg': 'var(--pd-canvas)',
  '--dk-card': 'var(--pd-surface)',
  '--dk-fg': 'var(--pd-ink)',
  '--dk-muted': 'var(--pd-muted)',
  '--dk-border': 'var(--pd-border)',
  '--dk-accent': 'var(--pd-primary)',
  '--dk-accent-tint': 'var(--pd-primary-tint)',
  '--dk-danger': 'var(--pd-danger)',
  '--dk-radius': 'var(--radius)',
  '--dk-font': 'var(--font-pd-body)',
  '--dk-font-display': 'var(--font-pd-display)',
});

export const DashkitTheme = () => <style>{DASHKIT_THEME}</style>;
```

Dark mode is opt-in: put a `dark` class on `.dk-root` or any ancestor (never the OS setting) and give the dark values with a scoped selector, e.g. `createTheme(darkVars, '.dark .dk-root')`. dashkit ships no dark palette; the playground has one to copy.

Danger and warning text on their tinted backgrounds is derived (the status colour mixed toward `--dk-fg`), so it stays readable when you change the status colours.

**Hosts on Tailwind 4.** dashkit's stylesheet is self-contained (its theme values are inlined, it has no preflight and every class is `dk:`-prefixed), but it uses Tailwind's unprefixed `--tw-*` internal variables and `@property` registrations, which a host Tailwind 4 build registers too. They agree when both are Tailwind 4; dashkit is built with 4.3.

## Widgets

A widget definition is data plus a React component. The registry validates `data` with `schema`, the editor builds the property panel from `form`, binding pickers from `slots`, and the AI tools describe the widget from `aiHint`.

```tsx
import { z } from 'zod';
import { builtinWidgets, createRegistry, defineWidget, formatValue } from 'dashkit/react';

interface GoalData {
  target: number;
  label: string;
}

export const goal = defineWidget<GoalData>({
  type: 'goal',
  version: 1,
  label: 'Goal',
  description: 'Progress of one metric toward a target.',
  icon: 'target',
  category: 'metrics',
  schema: z.object({ target: z.number().positive(), label: z.string() }).strict(),
  defaultData: { target: 100, label: 'Target' },
  slots: { value: { label: 'Value', shape: 'value', required: true } },
  defaultSize: { w: 4, h: 3 }, // grid cells: 4 of 12 columns, 3 rows of 48px
  minSize: { w: 3, h: 2 },
  maxSize: { w: 6, h: 4 },
  form: [
    { kind: 'number', key: 'target', label: 'Target', min: 0 },
    { kind: 'text', key: 'label', label: 'Target label' },
  ],
  aiHint:
    'Use when the brief names a target for one metric (e.g. "100 leads this month"). Bind `value` to the metric and set data.target to the number.',
  Component: ({ widget, data }) => {
    const slot = data.value;
    if (slot?.shape !== 'value') return null;
    const pct = Math.min(100, (slot.value / widget.data.target) * 100);
    return (
      <div className="goal">{/* your own classes; dashkit's utilities are dk:-prefixed */}
        <strong>{formatValue(slot.value, slot.format, slot.unit)}</strong>
        <span>
          {' '}of {formatValue(widget.data.target, slot.format, slot.unit)} {widget.data.label}
        </span>
        <div role="progressbar" aria-valuenow={Math.round(pct)} style={{ width: `${pct}%`, height: 4, background: 'var(--dk-accent)' }} />
      </div>
    );
  },
});

export const registry = createRegistry([...builtinWidgets, goal]);
```

The `Component` receives `widget` (with typed `data`), `data` (resolved slots by name), `state` (`loading | ready | error | empty`), `error` and `mode` (`view | edit`). The frame handles loading, empty and error states around it. The widget's cell has a fixed height, so lay the component out to fill it (`height: 100%`) and let long content scroll inside. Form field kinds: `text`, `textarea`, `number`, `select`, `toggle`, `segmented`, `color-token`, `array`, `group`. Bump `version` and add `migrate(data, from)` when you change the data shape.

Built-ins, with default size (w×h) and min..max:

| Type | Default | Min | Max |
| --- | --- | --- | --- |
| `heading` | 12×1 | 3×1 | 12×3 |
| `kpi` | 3×3 | 2×3 | 6×4 |
| `kpi-strip` | 12×3 | 8×3 | 12×4 |
| `text` | 6×3 | 3×2 | 12×12 |
| `briefing` | 6×5 | 4×4 | 12×10 |
| `trend`, `bar`, `comparison` | 6×6 | 4×4 | 12×12 |
| `funnel` | 6×6 | 4×4 | 12×10 |
| `donut` | 4×6 | 3×5 | 6×10 |
| `leaderboard` | 6×6 | 3×4 | 12×12 |
| `table` | 12×6 | 6×4 | 12×16 |

`kpi` takes an optional `spark` slot (the same metric `by: 'day'`) for a sparkline. The charts are vendored [Tremor Raw](https://tremor.so) components on recharts (Apache-2.0, notice in `src/react/ui/LICENSE-tremor`).

## AI

`dashkit/ai` has no provider SDK and no network code. It gives you four tools, an executor and prompt text:

| Tool | Does |
| --- | --- |
| `dashboard_describe` | Returns `summarize(doc)`: one line per widget with its id, type, title, size and position |
| `dashboard_apply` | Applies a list of ops (every op except `replaceDashboard`) |
| `dashboard_propose_widget` | Adds one widget: `{ type, title?, size?, after?, bindings }`; the id is generated |
| `catalog_search` | Finds metrics and dimensions by key, label or description |

```ts
import { applyToolCall, systemPromptFragment, toolDefinitions } from 'dashkit/ai';
import type { Catalog, Dashboard, Registry } from 'dashkit/core';

declare const registry: Registry, catalog: Catalog;

const openaiTools = toolDefinitions({ registry, catalog, style: 'openai' }); // { type: 'function', function: { name, description, parameters } }
const anthropicTools = toolDefinitions({ registry, catalog, style: 'anthropic' }); // { name, description, input_schema }
const neutralTools = toolDefinitions({ registry, catalog, style: 'json-schema' }); // { name, description, parameters, 'x-dashkit-widgets'? }

const system = `You are the analytics assistant.\n\n${systemPromptFragment({ registry, catalog })}`;

// For each tool call the model makes:
export function runTool(doc: Dashboard, name: string, args: unknown) {
  const result = applyToolCall(doc, { name, args }, { registry, catalog }); // args may be the raw JSON string
  if (result.ok) return { doc: result.doc, reply: { ok: true, diff: result.diff, result: result.result } };
  return { doc, reply: result }; // { ok: false, error: { code, path, message } }: send it back so the model retries
}
```

Tool schemas are narrowed to your catalog (metric, dimension and window enums) and registry (widget types), so regenerate them when either changes.

`applyToolCall(doc, call, { registry, catalog, author? })` never throws for bad input and never mutates `doc`:

- `{ ok: true, doc, diff, result }`: the new document, human-readable change lines (`diff`), and the tool's own result (the outline for describe, `{ applied }` for apply, `{ widgetId }` for propose, matches for search).
- `{ ok: false, error: { code, path, message } }`: nothing changed.

Only new validation errors reject a call. Errors already present in `doc` (say, a metric that has since left the catalog) do not block other edits, so a model can repair a broken dashboard one step at a time. Errors are matched by the widget id they belong to (paths are rewritten from `widgets.<i>…` to `widget:<id>…`), so moving widgets around does not make an old error look new. Replacing one bad value with another bad value counts as new.

`systemPromptFragment({ registry, catalog })` is markdown to append to your system prompt: tool rules, each widget type with its `aiHint`, slots and default, min and max size, metrics with format, unit and polarity (`[currency, USD, lower is better]`), dimensions, windows, grid rules (12 columns of 48px rows, headings as sections, `after` placement, never pixels or CSS) and worked examples, including moving and resizing. It is deterministic, so it caches well.

`generateFromBrief(brief, llm, { registry, catalog, title?, maxRounds?, style? })` builds a new dashboard from a sentence by looping your model over the tools (default 6 rounds, stops when a round makes no tool calls). You supply the model call:

```ts
import { generateFromBrief, type LlmFn } from 'dashkit/ai';
import type { Catalog, Registry } from 'dashkit/core';

declare const registry: Registry, catalog: Catalog;
declare function callModel(req: { system: string; messages: unknown[]; tools: unknown[] }): Promise<{ text?: string; toolCalls?: { id: string; name: string; args: unknown }[] }>;

const llm: LlmFn = async ({ system, messages, tools }) => callModel({ system, messages, tools }); // map to and from your provider here

const { doc, transcript } = await generateFromBrief('spend and leads by client, trend of spend', llm, { registry, catalog });
```

`messages` use roles `user`, `assistant` (with `toolCalls`) and `tool` (with `toolCallId`, content is the JSON result).

`summarize(doc)` (what `dashboard_describe` returns) looks like this:

```text
# Weekly spend (10 widgets)
- [h-weekly-spend] heading "Weekly spend" 12×2 @0,0 (h1)
- [k-spend] kpi "Spend" 3×3 @0,2  value→spend last_30d; spark→spend by day last_30d
- [w-spend-trend] trend "Spend by day" 8×7 @0,5  series→spend by day last_30d
```

### Non-JS backends

When your agent runs in Python (or anything else), keep one applier: the frontend. The backend only proposes ops.

1. **Export the tool definitions** with a small Node script and check the output into the backend. `json-schema` style is provider-neutral; `x-dashkit-widgets` on `dashboard_propose_widget` lists the widget types, slots and form `fields` (key, label, kind, options) for hosts that build their own prompt. Strip it before sending the definition to a provider.

   ```ts
   // scripts/export-dashkit-tools.ts (run with tsx after the catalog or widgets change)
   import { writeFileSync } from 'node:fs';
   import { systemPromptFragment, toolDefinitions } from 'dashkit/ai';
   import { builtinWidgets, createRegistry } from 'dashkit/react';
   import { catalog } from './catalog';

   const registry = createRegistry(builtinWidgets);
   writeFileSync('backend/dashkit/tools.json', JSON.stringify(toolDefinitions({ registry, catalog, style: 'json-schema' }), null, 2));
   writeFileSync('backend/dashkit/prompt.md', systemPromptFragment({ registry, catalog }));
   writeFileSync('backend/dashkit/catalog.json', JSON.stringify(catalog, null, 2)); // functions (dimension values) are dropped
   ```

2. **Register them in your agent.** Executors validate the arguments against the schema and return ops; they never touch the stored document. `dashboard_describe` answers from the summary the frontend sends with the chat request (step 3), so it reflects the dashboard as it was when the turn started, not ops queued earlier in the same turn.

   ```python
   TOOLS = json.load(open("dashkit/tools.json"))
   CATALOG = json.load(open("dashkit/catalog.json"))
   SCHEMAS = {t["name"]: t["parameters"] for t in TOOLS}

   def dashboard_describe(args, ctx):
       return {"ok": True, "result": ctx.request.summary}  # summarize(doc) from the frontend

   def dashboard_apply(args, ctx):
       jsonschema.validate(args, SCHEMAS["dashboard_apply"])
       ctx.dashboard_ops.extend(args["ops"])
       return {"ok": True, "result": {"applied": len(args["ops"])}}

   def dashboard_propose_widget(args, ctx):
       jsonschema.validate(args, SCHEMAS["dashboard_propose_widget"])
       widget_id = secrets.token_hex(6)
       widget = {"id": widget_id, "type": args["type"], "bindings": args["bindings"]}
       widget.update({k: args[k] for k in ("title", "size") if k in args})
       op = {"op": "addWidget", "widget": widget}
       if "after" in args:  # right of that widget if it fits, else the row below; absent: a new row at the bottom
           op["after"] = args["after"]
       ctx.dashboard_ops.append(op)
       return {"ok": True, "result": {"widgetId": widget_id}}

   def catalog_search(args, ctx):
       jsonschema.validate(args, SCHEMAS["catalog_search"])
       q = args["query"].strip().lower()
       hit = lambda item: any(q in (item.get(f) or "").lower() for f in ("key", "label", "description"))
       return {"ok": True, "result": {
           "metrics": [m for m in CATALOG["metrics"] if hit(m)][:20],
           "dimensions": [{"key": d["key"], "label": d["label"]} for d in CATALOG["dimensions"] if hit(d)],
           "windows": CATALOG["windows"],
       }}

   EXECUTORS = {"dashboard_describe": dashboard_describe, "dashboard_apply": dashboard_apply,
                "dashboard_propose_widget": dashboard_propose_widget, "catalog_search": catalog_search}
   for t in TOOLS:
       agent.register_tool(name=t["name"], description=t["description"], parameters=t["parameters"], executor=EXECUTORS[t["name"]])

   # ... return ChatResponse(reply=text, dashboard_ops=ctx.dashboard_ops)
   ```

   Append `prompt.md` to the system prompt when the user is on a dashboard page.

3. **Send the summary, apply the ops on the frontend** through the editor so the change lands in its history, then save. Running `applyToolCall` first gives you the same "new errors only" check and the `diff` lines to show in the chat:

   ```ts
   import { applyToolCall } from 'dashkit/ai';
   import { summarize, type Catalog, type Op, type Registry } from 'dashkit/core';
   import type { Store } from 'dashkit/adapters';
   import type { DashboardEditorApi } from 'dashkit/react';

   declare function postChat(body: { message: string; dashboard_id: string; summary: string }): Promise<{ reply: string; dashboard_ops?: Op[] }>;

   export async function askAssistant(message: string, api: DashboardEditorApi, store: Store, ctx: { registry: Registry; catalog: Catalog }) {
     const doc = api.getDoc();
     const res = await postChat({ message, dashboard_id: doc.id, summary: summarize(doc) });
     const ops = res.dashboard_ops ?? [];
     if (ops.length === 0) return { reply: res.reply, diff: [] as string[] };
     const check = applyToolCall(api.getDoc(), { name: 'dashboard_apply', args: { ops } }, ctx);
     if (!check.ok) return { reply: res.reply, error: check.error.message }; // tell the user (and the model, next turn)
     const before = api.getDoc();
     const next = api.applyAll(ops, 'ai'); // one undo step
     if (next === before) return { reply: res.reply, error: 'rejected by the editor' }; // reason shown in the toolbar
     await store.save(next);
     api.markSaved();
     return { reply: res.reply, diff: check.diff };
   }
   ```

## Playground

`playground/` is a Next.js app that runs the kit with mock data and a keyword-based fake model: editor, renderer, "Generate from brief" and a chat panel that applies ops through `apiRef.applyAll`. Its sample board is "Weekly spend" (a level-1 heading, four KPIs with sparklines, a trend, a donut, a table, a leaderboard and a note). From the repo root: `npm install && npm run playground` (port 3100). See `playground/README.md` for URL parameters.

![Playground, view mode](docs/screenshots/playground-v2-view.png)
![Playground, edit mode with a chart selected](docs/screenshots/playground-v2-edit.png)

## Upgrading from 0.2

- Run `migrate(doc, { registry })` on every document you load. Stored v1 documents (sections and spans) become v2 (headings and positioned widgets) in memory; the next save stores v2, so no bulk migration is needed.
- If your backend validates saved documents, deploy it first accepting both v1 and v2 (v1 against the 0.2 schema), then the frontend; re-tighten to v2 only once no 0.2 tabs remain (see `CHANGELOG.md`, Upgrading).
- Backends that validate with `dashkit/schema.json` or the exported tool definitions must re-sync both (the schema `$id` is now `…/dashboard-v2.json`). Code that builds ops must drop `sectionId`, `span` and the section ops; see `CHANGELOG.md`.
- Remove `@dnd-kit/core` and `@dnd-kit/sortable` if nothing else uses them. On React 19.2+, add the `react-is` override (see [Install](#install)).
- Replace styles that targeted the old class names (`.dk-widget`, `.dk-section`, …) with `--dk-*` overrides. `header="hero"` is gone: add a level-1 `heading` widget.

## Versioning and limits

- `0.x`: breaking changes can land in minor versions; see `CHANGELOG.md`.
- Peers: React and React DOM 19, recharts `^2.15` (with `react-is` overridden to your React version on 19.2+), zod `>=3.25 <4`; vitest 3+ only for the contract suites. Node 22 or newer (`engines`). ESM only.
- Documents carry `version: 2`. `migrate(doc, { registry })` upgrades older documents and per-widget data, and clamps widget sizes into their type's range (re-normalizing only when one was out of range); it is a no-op on current, in-range documents. `dashkit/schema.json` is the dashboard document as JSON Schema (draft 2020-12, `$id` `https://dashkit.dev/schema/dashboard-v2.json`), for validating documents in other languages, e.g. before a backend writes one.
- Layout: `x` 0–11, `y` 0–999, `w` 1–12, `h` 1–24, `x + w <= 12` (else `LAYOUT_OUT_OF_BOUNDS`); sizes must also fit the widget type's `minSize`..`maxSize` (else `SIZE_OUT_OF_RANGE`). Locked widgets cannot be moved or resized (`WIDGET_LOCKED`) but are pushed down by others.
- OpenAI `strict: true` structured outputs reject the tool schemas (optional properties and `anyOf`); register the tools with default function calling.
- `styles.css` uses CSS container queries and `color-mix()`, so it targets evergreen browsers.
- The schema checks structure only. Widget data, bindings against the catalog and sizes are checked by `validate(doc, { registry, catalog })`, which needs the registry, so do it in JS.
