# dashkit

A build-your-own dashboard kit. A dashboard is a JSON document: a flat list of widgets, each placed on a 12-column grid of 48px rows (`layout: { x, y, w, h }`). A data widget holds one `query` (metrics by key, optionally split by a dimension or over time) and draws the `Frame` the host answers it with. You change the document only through typed operations, so the editor UI, your code and an AI model all use the same path and share one undo history. The host supplies two small adapters, a `DataSource` (catalog plus frames) and a `Store` (persistence), and optionally a `BriefingProvider` for the live AI briefing. dashkit supplies the rest:

| Entry point | What it holds | Runs in |
| --- | --- | --- |
| `dashkit/core` | Document and query schemas (`Query`, `Frame`), ops (`apply`, `applyAll`), layout engine, validation, history, migrations (v1 → v2 → v3), `summarize`, `diff` | Anywhere (only needs zod) |
| `dashkit/react` | Widget registry, 10 built-in widgets, `DashboardRenderer` and `DashboardEditor` (on react-grid-layout), `BriefingProvider`, theme | React 19 |
| `dashkit/ai` | Tool definitions for OpenAI, Anthropic or plain JSON Schema, `applyToolCall`, `systemPromptFragment`, `generateFromBrief` | Anywhere |
| `dashkit/adapters` | `DataSource` / `Store` interfaces, memory store, mock data source (deterministic frames), fetch adapters for the reference routes | Anywhere |

Also exported: `dashkit/adapters/contract` (vitest suites for your adapters), `dashkit/styles.css` (the compiled stylesheet) and `dashkit/schema.json`.

## Install

Peer dependencies (install them in the host app):

```sh
npm install react@^19 react-dom@^19 recharts@^2.15 "zod@>=3.25 <4"
# optional, only for dashkit/adapters/contract:
npm install -D vitest
```

recharts 2 depends on an older `react-is`. On React 19.2 or newer, override it to your React version, or charts fail to render:

```jsonc
// package.json
"overrides": { "recharts": { "react-is": "19.2.0" } } // your exact react version
```

dashkit installs its own runtime dependencies: `radix-ui`, `@tanstack/react-table`, `cmdk`, `lucide-react`, `class-variance-authority`, `clsx`, `tailwind-merge`, `react-grid-layout` and `zod-to-json-schema`. They are the vendored kit's (see [Widgets](#widgets)); the host installs none of them.

dashkit is not on npm. Depend on it from a local checkout or from git, in the host's `package.json`:

```jsonc
// a local checkout (run `npm run build` in it first, and again after pulling changes)
"dashkit": "file:../dashkit"
// or git (dashkit's `prepare` script builds dist/ during install)
"dashkit": "git+https://github.com/<owner>/dashkit.git#v0.4.0"
```

`file:` symlinks the checkout, so a bundler can pick up dashkit's own dev copies of React or zod from `../dashkit/node_modules`. If you see "Invalid hook call" or zod errors about mismatched instances, install a tarball instead: `npm pack` in dashkit, then `npm install ../dashkit/dashkit-0.4.0.tgz` in the host.

Import the stylesheet once. It is compiled from Tailwind 4 with every class prefixed `dk:` and without Tailwind's preflight reset, so the host needs no Tailwind and nothing in it restyles the host page (the one global side effect is listed under [Theme](#theme), "Host notes"). Next.js also needs the package in `transpilePackages`:

```js
// next.config.mjs
export default { transpilePackages: ['dashkit'] };
```

```ts
// app/layout.tsx (or any root module)
import 'dashkit/styles.css';
```

The stylesheet names Inter and Bricolage Grotesque in `--dk-font` / `--dk-font-display` but does not load them. Load them yourself or point the variables at your own fonts (see [Theme](#theme)).

## Quick start

Render a dashboard with fake data:

```tsx
import 'dashkit/styles.css';
import { applyAll, createDashboard, type Catalog } from 'dashkit/core';
import { DashboardDataProvider, DashboardRenderer, builtinWidgets, createRegistry } from 'dashkit/react';
import { createMockDataSource } from 'dashkit/adapters';

const catalog: Catalog = {
  metrics: [
    { key: 'revenue', label: 'Revenue', unit: 'USD', format: 'currency', dimensions: ['client'], over: true, additive: true },
  ],
  dimensions: [{ key: 'client', label: 'Client' }],
  windows: [{ preset: 'last_30d', label: 'Last 30 days' }],
};
const registry = createRegistry(builtinWidgets);
const dataSource = createMockDataSource(catalog);
const last30 = { preset: 'last_30d' };
const revenue = [{ metric: 'revenue' }];
const doc = applyAll(createDashboard({ title: 'Sales' }), [
  { op: 'addWidget', widget: { id: 'h', type: 'heading', title: 'Sales', data: { level: 1 } } },
  { op: 'addWidget', after: 'h', widget: { id: 'rev', type: 'kpi', title: 'Revenue', query: { metrics: revenue, window: last30, compare: 'previous', spark: true } } },
  { op: 'addWidget', after: 'rev', widget: { type: 'trend', title: 'Revenue by day', size: { w: 9, h: 6 }, query: { metrics: revenue, over: 'day', window: last30 } } },
], { registry, author: 'code' });

export function SalesDashboard() {
  return (
    <DashboardDataProvider dataSource={dataSource} registry={registry}>
      <DashboardRenderer doc={doc} registry={registry} catalog={catalog} />
    </DashboardDataProvider>
  );
}
```

An `addWidget` op carries the query as `widget.query`; the document stores it as `widget.bindings.query`. `DashboardDataProvider` batches every widget's query into one `dataSource.query` call per tick and caches the frames (`ttlMs`, default 60 s). With `catalog`, the renderer validates each widget and draws an error frame for invalid ones. Pass `mode="edit"` to also show hidden widgets (dimmed, in their stored place).

### Layout

`addWidget` places a widget by `at: { x, y }` if given; otherwise by `after: widgetId` (to the right of that widget when it fits in the row and those cells are free, else at `x = 0` below the tallest widget sharing that widget's rows); otherwise at `x = 0` below the lowest widget. `size: { w, h }` defaults to the type's `defaultSize`. `moveWidget`, `resizeWidget` and `setLayout` rearrange. Every op returns a normalized layout: overlaps are pushed down, then everything compacts upward, the same algorithm react-grid-layout uses, so a stored document renders exactly as stored.

The renderer is react-grid-layout in static mode: 12 columns from 768px of container width (the stored layout), 6 columns from 480px and 1 column below; the 6- and 1-column layouts are generated and never stored. Rows are 48px with 16px gaps (`theme.density: 'compact'` gives 12px).

- The renderer's root `.dk-root` is `width: 100%` and measures itself, so its parent must give it a definite width. Until it is measured the grid renders an empty placeholder of its desktop height; pass `width` to render immediately (tests, SSR).
- Each widget fills its cell, so a `Frame` must fill its height (`height: 100%`).
- Sections are `heading` widgets: `title` is the heading text, `data.level` 1 (24px), 2 (20px, default) or 3 (16px), and `data.description` a muted line under it. Use a level-1 heading at the top as the page title; dashkit renders no page header of its own. A level-1 heading is vertically centred in its cell; levels 2 and 3 sit at the bottom, next to the widgets they title.
- Each widget frame shows a window badge next to its title (`Last 7 days · all clients`, from `windowBadge(widget, catalog)`), shortened to `7d · all` in cards under 260px and hidden under 200px.

## Queries and frames

Document version 3. A widget's `bindings` is `{ query?: Query }`; only `heading`, `text` and `briefing` take no query. A widget asks one question (its `query`) and the host answers it with one `Frame`.

```ts
type Query = {
  metrics: { metric: string; label?: string }[]; // 1..20 in order, metric ids unique; `label` names a column or funnel step
  by?: string;                                    // a catalog dimension to split rows by (never time)
  over?: 'day' | 'week' | 'month';                // time grain: one row per bucket, weeks are ISO weeks starting Monday
  window: { preset: string } | { from: string; to: string }; // a catalog preset, or YYYY-MM-DD dates (both inclusive)
  filters?: Record<string, string[]>;             // dimension → allowed values
  compare?: 'previous';                           // also return the previous period
  sort?: { metric: string; dir: 'asc' | 'desc' }; // a metric in `metrics`; ignored with `over` (time ascending)
  limit?: number;                                 // 1..100; with `by`
  spark?: boolean;                                // also return a per-metric daily series over the window
};

type Frame = {
  columns: { key: string; label: string; format: Format; polarity?: Polarity }[];
  rows: { key: string; label: string; values: Record<string, number | null>; previous?: Record<string, number | null> }[];
  totals: { values: Record<string, number | null>; previous?: Record<string, number | null> };
  spark?: Record<string, { date: string; value: number | null }[]>;
  previousAvailable: boolean;                     // false for a window with no previous period ('maximum')
  window: { label: string; from: string; to: string };
};
```

`Format` is `integer | currency | percentage | decimal | compact` and `Polarity` is `higher_is_better | lower_is_better`. How a query maps to a frame:

| Query | Rows | Columns |
| --- | --- | --- |
| no `by`, no `over` | none; the answer is in `totals` | one per metric |
| `by` only | one per dimension value (`key` is the value id) | one per metric |
| `over` only | one per time bucket (`key` is the bucket's ISO start date) | one per metric |
| `over` and `by` | one per time bucket | one per dimension value: the top `limit` (default 5, max 8) ranked by the one metric over the whole window; the column `key` is the dimension value id |

`totals` of a ratio metric are recomputed from its parts (Σ numerator ÷ Σ denominator), never summed or averaged, and a zero denominator is `null`, not 0. A value the source cannot give is `null`; widgets draw "—".

Each built-in type allows only some query shapes (`QueryRules`). `validate()` and every op that changes a query enforce them, and so does the editor's query builder, which disables what would break a rule:

| Type | `metrics` | `by` | `over` | Notes |
| --- | --- | --- | --- | --- |
| `kpi` | exactly 1 | no | no | `spark` is on by default: a kpi query gets `spark: true` unless it sets `spark: false` |
| `kpi-strip` | 2..4 | no | no | |
| `trend` | 1..4, exactly 1 with `by` | optional (top N) | **required** | `over` defaults to `day` on a type change; all metrics share one format |
| `chart` | 1..4 | **required** | no | all metrics share one format; a donut takes exactly 1 additive metric |
| `funnel` | 1..8 | no | no | fewer than 2 steps draws "Add at least 2 steps" |
| `leaderboard` | 1..3 (first ranks) | **required** | no | |
| `table` | 1..20 | exactly one of `by` / `over` | | |

A query that breaks its type's rules fails with `QUERY_SHAPE`, and the message names the rule. Against the catalog, `validate()` also reports `METRIC_UNKNOWN`, `DIMENSION_UNSUPPORTED` (a metric does not list the `by` dimension), `GRAIN_UNSUPPORTED` (`over` on a metric the catalog does not mark `over: true`), and unknown filter dimensions or window presets. `changeWidgetType` keeps the query when it is valid for the new type; otherwise it keeps the metrics (cut to the new maximum), window, filters and compare, and sets `by` / `over` to the new type's default (`trend` → `over: 'day'`; `chart` and `leaderboard` → `by: 'client'`; `table` keeps whichever the old query had).

`QueryRules` is plain data except `check` (a function), on the widget definition (`query: { metrics, by, over, exactlyOneOfByOver?, maxMetricsWithBy?, spark?, check?, defaults }`), so your own widgets can declare one; `checkQueryShape` and `adaptQuery` are exported from `dashkit/core`. `check(query, data, catalog?)` returns a message for rules that need the widget data or the catalog (the donut rule).

The ops that touch a query are `addWidget` (`widget.query`), `setQuery { widgetId, query }` (replaces the whole query) and `clearQuery { widgetId }`.

## Editor

`DashboardEditor` is a full editor: toolbar (undo, redo, save, JSON view), an icon palette rail, the grid canvas and a property panel generated from each widget's `form`. It brings its own `DashboardDataProvider`.

- Drag a widget to move it and its corner handle to resize it; each gesture is one `setLayout` op, so one undo step. Click a palette tile to add that widget below the selected one (or at the bottom), or drag the tile onto a cell.
- The selected widget gets an accent ring, a type and size tag (`Trend · 8 × 7`) and a floating duplicate/hide/remove toolbar. Arrow keys move it one cell; Shift+arrows resize it.
- The property panel groups Layout (title, S/M/L/Full size presets, W/H steppers, X/Y nudges), Data and Appearance (the widget's `form`). Data is a query builder:
  - a metric list (add from a searchable catalog menu, reorder with drag or ↑/↓, rename, remove), headed "Steps" for a funnel, "Columns" for a table and "Metrics" otherwise;
  - a "Rows" picker (none or a dimension) and an "Over time" picker (none, day, week, month), each offering only what the widget's rules allow;
  - window (presets or a custom range), compare, sparkline, sort, limit and filters.

  Controls that would break a rule are disabled, with the reason in a tooltip, so an invalid query cannot be built. The panel is drawn with dashkit's vendored kit and does not use the host `components`.
- Editing needs room: when the editor's container is narrower than 1024px (the editor measures its own width, not the window), it keeps its toolbar and shows the dashboard read-only with the notice "Editing needs a wider window".

```tsx
import { useRef, useState } from 'react';
import type { Catalog, Dashboard } from 'dashkit/core';
import type { DataSource, Store } from 'dashkit/adapters';
import {
  BriefingProvider,
  DashboardEditor,
  builtinWidgets,
  createRegistry,
  type BriefingRequest,
  type BriefingResult,
  type ButtonProps,
  type DashboardEditorApi,
} from 'dashkit/react';

const registry = createRegistry(builtinWidgets);

function MyButton({ variant, className, type = 'button', ...rest }: ButtonProps) {
  const classes = ['btn', variant === 'primary' && 'btn-primary', className].filter(Boolean).join(' ');
  return <button type={type} className={classes} {...rest} />;
}

export function EditDashboard(props: {
  initial: Dashboard;
  catalog: Catalog;
  dataSource: DataSource;
  store: Store;
  briefing(req: BriefingRequest): Promise<BriefingResult>;
}) {
  const [doc, setDoc] = useState(props.initial);
  const apiRef = useRef<DashboardEditorApi>(null);
  return (
    <BriefingProvider onBriefing={props.briefing}>
      <DashboardEditor
        doc={doc}
        registry={registry}
        catalog={props.catalog}
        dataSource={props.dataSource}
        onChange={setDoc}
        onSave={async (d) => {
          await props.store.save(d);
        }}
        apiRef={apiRef}
        components={{ Button: MyButton }}
      />
    </BriefingProvider>
  );
}
```

| Prop | |
| --- | --- |
| `doc`, `registry`, `catalog`, `dataSource` | Required. A new `doc.id` starts a fresh history. A changed `doc` with the same id replaces the editor's copy unless it has unsaved edits. If you feed the saved document back in, return it as sent (only `meta.updatedAt` may differ, and that difference is ignored); any other change counts as a new document and clears undo history. |
| `onChange(doc)` | After every op, undo and redo. |
| `onSave(doc)` | Shows the Save button; the editor is marked clean once it resolves. |
| `apiRef` | Filled with `DashboardEditorApi`: `getDoc`, `apply(op, author?)`, `applyAll(ops, author?)`, `undo`, `redo`, `markSaved`, `select`. Ops applied here go through the editor's history (undoable, mark it dirty). They never throw: a rejected batch leaves the doc unchanged and shows the reason in the toolbar. |
| `components` | Swap the few primitives dashkit still takes from the host (`DashkitComponents`): `Frame` (the widget card, `WidgetFrameProps`), `Button` and `Input` (the toolbar's save, undo, title and JSON buttons), `Icon` (the editor's icons; without it they fall back to text glyphs) and `Markdown` (the `text` widget; without it text renders as plain preformatted text). The widgets and the editor's property panel, palette and query builder are drawn with dashkit's own kit and ignore them. `Menu` and `Select` are still accepted for compatibility but nothing in 0.4.0 renders them. The same object works on `DashboardRenderer` and `ComponentsProvider`. Pass a stable object (module-level or memoised): switching it between `undefined` and an object remounts the whole widget tree. |
| `className` | Added to the editor's `.dk-root`. |

A custom `Frame` must render `title`, `meta` (the window badge, after the title), `menu` and `children`, honour `state` (`loading`, `ready`, `empty`, `error`) and `error`, and fill its cell's height. Make it a CSS size container (`container-type: inline-size`, or the `dk:@container` class) so the badge and the widgets' container queries measure the card. The editor's selection chrome and drag surface sit on the grid item around the frame, so a custom frame needs nothing for editing. `heading` widgets render without a frame.

### Briefing

`briefing` widgets show a live AI summary of the board. They have no content of their own: wrap the renderer or editor in a `BriefingProvider` and answer its one callback.

```tsx
import { BriefingProvider, type BriefingRequest, type BriefingResult } from 'dashkit/react';

async function onBriefing(req: BriefingRequest): Promise<BriefingResult> {
  // req = { dashboardId, focus?, refresh }
  const res = await fetch(`/api/dashboards/${req.dashboardId}/briefing`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ focus: req.focus, refresh: req.refresh }),
  });
  if (!res.ok) throw new Error(`Briefing failed (${res.status})`);
  const body = await res.json(); // { parts, findings, generated_at, cached }
  return { parts: body.parts, findings: body.findings, generatedAt: body.generated_at, cached: body.cached };
}

<BriefingProvider onBriefing={onBriefing}>{/* renderer or editor */}</BriefingProvider>;
```

- `BriefingRequest` is exactly `{ dashboardId: string; focus?: string; refresh: boolean }`. `dashboardId` is the rendered document's `id`; `focus` is the widget's optional focus phrase; `refresh` is true when the reader pressed Refresh (skip any cached briefing).
- `BriefingResult` is `{ parts: { text: string; bold?: boolean }[]; findings: { text: string; tone: 'positive' | 'negative' | 'neutral' }[]; generatedAt: string; cached: boolean }`: a lead sentence (bold runs as `<strong>`) and a few toned findings.
- The widget shows a skeleton while loading, then the content with "Updated <relative time>" and a Refresh button, or an error with Retry (a failed Refresh keeps the old briefing and shows the error inline). A changed `focus` refetches after a short debounce. `onBriefing` may be a new function on every render; the provider hands widgets one stable fetcher.
- Without a `BriefingProvider` the widget says "Briefings need a host connection".

### Composing the editor yourself

`DashboardEditor` is `Toolbar`, `Palette`, `Canvas` (or `JsonView`) and `PropertyPanel` inside an `EditorProvider`, which takes the state from `useDashboardEditor`. Render them yourself to change the arrangement. Palette drags are plain HTML drag-and-drop carrying `PALETTE_DRAG_MIME`, so the palette and the canvas need no shared drag-and-drop scope; both only need the `EditorProvider`.

```tsx
import { Canvas, DashboardDataProvider, EditorProvider, Palette, PropertyPanel, Toolbar, useDashboardEditor } from 'dashkit/react';

function MyEditor({ doc, registry, catalog, dataSource }: Props) {
  const editor = useDashboardEditor(doc, { registry, catalog });
  return (
    <DashboardDataProvider dataSource={dataSource} registry={registry}>
      <EditorProvider editor={editor} registry={registry} catalog={catalog}>
        <div className="dk-root my-editor">
          <Toolbar />
          <Palette />
          <Canvas />
          <PropertyPanel />
        </div>
      </EditorProvider>
    </DashboardDataProvider>
  );
}
```

## Host adapters

```ts
import type { Catalog, Dashboard, Frame, Query } from 'dashkit/core';
import type { DashboardSummary } from 'dashkit/adapters';

interface DataSource {
  catalog(): Promise<Catalog>;
  /**
   * Answer each query with one frame, in order (the result has the same length as `queries`).
   * A query that fails on its own is `null` at its index; only that widget shows an error.
   */
  query(queries: Query[]): Promise<Array<Frame | null>>;
}

interface Store {
  list(): Promise<DashboardSummary[]>; // { id, title, updatedAt }, newest first
  load(id: string): Promise<Dashboard>;
  save(doc: Dashboard): Promise<Dashboard>;
  remove(id: string): Promise<void>;
}
```

One `query` call carries every widget's query on screen, so a single bad query must not fail the request. Catch errors per query on the backend and return `null` at that index: only that widget shows "Data source returned no data for this query" and the rest render. Reject (or return non-2xx) only when the whole request fails; then every widget in the batch shows the error. (`resolve(bindings, shapes)` and the `ResolvedSlot` types of 0.3 are gone.)

A `Catalog` lists:

- `metrics`: `key`, `label`, `format` (`integer | currency | percentage | decimal | compact`), the `dimensions` it can be split by, and optional `unit`, `description`, `aggregation`, `polarity` (`higher_is_better`, the default, or `lower_is_better`, which colours a falling cost as good news), `over` (the metric can be shown over time; **default false**, so set it on every metric that has history) and `additive` (parts add up to a whole; ratios are `false`, and the donut is offered only for metrics that are not `false`);
- `dimensions`: `key`, `label`, optional async `values`;
- `windows`: `preset`, `label`.

`CatalogSchema`, `QuerySchema` and `FrameSchema` in `dashkit/core` define these exactly.

What a source has to get right when it builds a frame:

- **Previous period.** With `compare: 'previous'`, fill `previous` on every row and in `totals` from the period before the window: calendar windows (this/last week, month, quarter, year) compare with the preceding calendar period of the same kind, cut to the same elapsed length for the "this_*" windows; `today` with yesterday and `yesterday` with the day before; `last_Nd` with the N days immediately before; a custom range with the same-length range immediately before. A window with no previous period (`maximum`) sets `previousAvailable: false` and no `previous` values; widgets then show "—" instead of a change.
- **Ratios.** Every total, bucket and previous value of a ratio is Σ numerator ÷ Σ denominator (cost per mille × 1000), `null` for a zero denominator.
- **Percentages** are 0–100 (`4.8` means 4.8%), as `format: 'percentage'` prints them.
- **`spark`.** A daily series per metric over the window, drawn by the kpi widget.

If your API follows the reference routes, use the fetch adapters:

| Route | Body / response |
| --- | --- |
| `GET {base}/dashboards` | → `{ items: DashboardSummary[] }` |
| `GET {base}/dashboards/:id` | → `Dashboard` |
| `PUT {base}/dashboards/:id` | `Dashboard` → `Dashboard` |
| `DELETE {base}/dashboards/:id` | → empty or any JSON |
| `GET {base}/dashboards/catalog` | → `Catalog` |
| `POST {base}/dashboards/query` | `{ queries }` → `{ frames: (Frame \| null)[] }` |
| `POST {base}/dashboards/{id}/briefing` | not called by the adapters; the endpoint your `BriefingProvider` calls (see [Briefing](#briefing)) |

In routers that match in declaration order (FastAPI, Express), declare `GET /dashboards/catalog` and `POST /dashboards/query` before `/dashboards/{id}`, or `catalog` is captured as an id. A route may cap the queries per request (Birdy's takes 50); `createFetchDataSource` sends one request per `query()` call, so a host with a cap chunks in its own `DataSource` wrapper.

```ts
import { createFetchDataSource, createFetchStore } from 'dashkit/adapters';

const authedFetch: typeof fetch = (input, init) =>
  fetch(input, { ...init, credentials: 'include', headers: { ...init?.headers, 'X-Client': 'web' } });

export const dataSource = createFetchDataSource('/api', authedFetch);
export const store = createFetchStore('/api', authedFetch);
```

Non-2xx responses reject with `DashkitError` code `HTTP_<status>`; network failures with `NETWORK`; unparseable bodies with `BAD_RESPONSE`. `createMemoryStore(initialDocs?)` and `createMockDataSource(catalog, { seed?, today?, ratios?, scales? })` cover tests and demos: the mock answers any valid query with deterministic frames from one daily cube per (metric, dimension value, day), so a total equals the sum of its rows, buckets add up to the window and ratios are recomputed from their parts; `scales` multiplies a metric's daily values to give a demo believable proportions.

Check your own adapters against the same contract the built-ins pass:

```ts
// my-adapters.test.ts
import { runDataSourceContract, runStoreContract } from 'dashkit/adapters/contract';
import { createFetchDataSource } from 'dashkit/adapters';
import { catalog } from './catalog';
import { createSqlStore, emptyTestDatabase } from './sql-store';

runStoreContract('sql store', () => createSqlStore(emptyTestDatabase()));
runDataSourceContract('api data source', () => createFetchDataSource('http://localhost:8000/api'), catalog);
```

The store factory must return a fresh, empty store each call. The data-source suite needs at least one metric with a dimension.

## Theme

Everything renders inside a `.dk-root` element and reads these CSS variables (`DK_VARS` exports the list):

| Group | Variables |
| --- | --- |
| Surfaces and text | `--dk-bg`, `--dk-card`, `--dk-fg`, `--dk-body`, `--dk-muted`, `--dk-subtle`, `--dk-border`, `--dk-border-strong`, `--dk-table-head` |
| Accent | `--dk-accent`, `--dk-accent-tint`, `--dk-accent-pale`, `--dk-accent-fg` |
| Status | `--dk-success`, `--dk-success-bg`, `--dk-danger`, `--dk-danger-bg`, `--dk-warning`, `--dk-warning-bg`, `--dk-info` |
| Charts | `--dk-chart-1`, `--dk-chart-2`, `--dk-chart-3`, `--dk-chart-4`, `--dk-chart-5`, `--dk-chart-6`, `--dk-chart-7`, `--dk-chart-8` |
| Shape and type | `--dk-radius`, `--dk-shadow`, `--dk-shadow-pop`, `--dk-font`, `--dk-font-display` |

The eight chart tokens `--dk-chart-1..8` are the series palette: charts, sparklines, funnel steps and legends take colours from them in order (a chart of up to eight series never repeats one), and the donut's "Other" slice is a neutral, not a chart colour. They are in `DK_VARS` and `createTheme`, so override them together with the rest, and cover all eight when you change any: a host that sets only 1–5 gets dashkit's defaults for 6–8.

The variables are the only way to theme dashkit: every colour, radius, shadow and font in the compiled utilities reads one of them, and Tailwind's own palette is not in the stylesheet. Defaults are Birdy's palette (`--dk-chart-1` … `--dk-chart-5` are `#5B3FD6`, `#2E9E8F`, `#E0920A`, `#98989E`, `#A8457A`; `--dk-chart-6` … `--dk-chart-8` are `#2F6FD0`, `#CF4A3A`, `#8F5FC2`, added so a chart of up to eight series never repeats a colour; adjacent colours checked for colour-blind separation).

How to override:

- Target `.dk-root` with an unlayered rule. The defaults sit on `:where(.dk-root)`, which has zero specificity, so any `.dk-root { … }` rule wins whichever stylesheet loads first.
- A rule inside a cascade `@layer` (for example Tailwind's `@layer base` in your own CSS) loses to the unlayered defaults. Keep the override outside any layer.
- Variables set on `:root` or `body` do not reach dashkit, because `.dk-root` declares its own values. Map them onto `.dk-root` instead: `.dk-root { --dk-accent: var(--brand); }`.

`createTheme(vars, selector = '.dk-root')` returns such a rule; unknown names and values containing `; { } < >` are dropped. Map your own tokens onto it, for example Birdy's:

```tsx
import { createTheme } from 'dashkit/react';

const DASHKIT_THEME = createTheme({
  '--dk-bg': 'var(--pd-canvas)',
  '--dk-card': 'var(--pd-surface)',
  '--dk-fg': 'var(--pd-ink)',
  '--dk-muted': 'var(--pd-muted)',
  '--dk-border': 'var(--pd-border)',
  '--dk-accent': 'var(--pd-primary)',
  '--dk-accent-tint': 'var(--pd-primary-tint)',
  '--dk-danger': 'var(--pd-danger)',
  '--dk-radius': 'var(--radius)',
  '--dk-font': 'var(--font-pd-body)',
  '--dk-font-display': 'var(--font-pd-display)',
});

export const DashkitTheme = () => <style>{DASHKIT_THEME}</style>;
```

Dark mode is opt-in: put a `dark` class on `.dk-root` or any ancestor (never the OS setting) and give the dark values with a scoped selector, e.g. `createTheme(darkVars, '.dark .dk-root')`. dashkit ships no dark palette; the playground has one to copy.

**Base reset.** Without Tailwind's preflight, the vendored kit still needs the slice of it that controls inherit from. dashkit ships that slice inside `@layer base`, scoped to `.dk-root`: border-box sizing, `border: 0 solid var(--dk-border)` on every element (an element has no border until a `dk:border` utility draws one, and a `<button>` or `<input>` never keeps the browser's 2px outset or inset bevel), and for `button`, `input`, `select` and `textarea` `font`, `letter-spacing` and `color` inherited with a transparent background and no padding. It never leaves `.dk-root`, so it does not restyle the host page, and because it is in the base layer every `dk:` utility beats it. The `.dk-root` class gives it more specificity than a host's own bare `*` base rule (Tailwind's `* { border-color: … }`), so the host's reset does not win inside dashkit. If your own CSS styles bare form controls inside a dashkit root, override with a `dk:` class or an unlayered rule.

Danger and warning text on their tinted backgrounds is derived (the status colour mixed toward `--dk-fg`), so it stays readable when you change the status colours.

**Host notes.** The stylesheet is scoped to `.dk-` classes and `.dk-root`, with these exceptions that reach outside it:

- `tw-animate-css` (the kit's popover and menu animations) adds global `@keyframes enter` and `@keyframes exit`, and `@property` registrations for `--tw-enter-*`, `--tw-exit-*` and `--tw-animation-*`. Tailwind's own `animate-spin` / `animate-pulse` add global `@keyframes spin` and `pulse`. A host with a keyframe of the same name (`spin` is common) gets whichever stylesheet loads last; rename yours if it differs.
- `react-grid-layout`'s stylesheet adds its `.react-grid-*` / `.react-resizable-*` classes.

**Hosts on Tailwind 4.** dashkit's stylesheet is self-contained (its theme values are inlined, it has no preflight and every class is `dk:`-prefixed), but it uses Tailwind's unprefixed `--tw-*` internal variables and `@property` registrations, which a host Tailwind 4 build registers too. They agree when both are Tailwind 4; dashkit is built with 4.3.

## Widgets

A widget definition is data plus a React component. The registry validates `data` with `schema`, the editor builds the property panel from `form` (and its query builder from `query`, the type's [query rules](#queries-and-frames)), and the AI tools describe the widget from `aiHint` and `query`.

```tsx
import { z } from 'zod';
import { builtinWidgets, createRegistry, defineWidget, formatValue } from 'dashkit/react';

interface GoalData {
  target: number;
  label: string;
}

export const goal = defineWidget<GoalData>({
  type: 'goal',
  version: 1,
  label: 'Goal',
  description: 'Progress of one metric toward a target.',
  icon: 'target',
  category: 'metrics',
  schema: z.object({ target: z.number().positive(), label: z.string() }).strict(),
  defaultData: { target: 100, label: 'Target' },
  query: { metrics: { min: 1, max: 1 }, by: 'forbidden', over: 'forbidden', defaults: {} },
  defaultSize: { w: 4, h: 3 }, // grid cells: 4 of 12 columns, 3 rows of 48px
  minSize: { w: 3, h: 2 },
  maxSize: { w: 6, h: 4 },
  form: [
    { kind: 'number', key: 'target', label: 'Target', min: 0 },
    { kind: 'text', key: 'label', label: 'Target label' },
  ],
  aiHint:
    'Use when the brief names a target for one metric (e.g. "100 leads this month"). Give it a query with that one metric and set data.target to the number.',
  Component: ({ widget, frame }) => {
    const column = frame?.columns[0];
    const value = column ? frame?.totals.values[column.key] : undefined;
    if (!column || value == null) return null;
    const pct = Math.min(100, (value / widget.data.target) * 100);
    return (
      <div className="goal">{/* your own classes; dashkit's utilities are dk:-prefixed */}
        <strong>{formatValue(value, column.format)}</strong>
        <span>
          {' '}of {formatValue(widget.data.target, column.format)} {widget.data.label}
        </span>
        <div role="progressbar" aria-valuenow={Math.round(pct)} style={{ width: `${pct}%`, height: 4, background: 'var(--dk-accent)' }} />
      </div>
    );
  },
});

export const registry = createRegistry([...builtinWidgets, goal]);
```

The `Component` receives `widget` (with typed `data` and its `bindings.query`), `frame` (the `Frame` the data source answered the query with; absent while loading the first time, on error, when empty and for widgets without a query), `state` (`loading | ready | error | empty`), `error`, `mode` (`view | edit`) and `catalog` (when the renderer was given one). The `query` rules let `validate()` and the editor reject a query your widget cannot draw. The frame handles loading, empty and error states around it. The widget's cell has a fixed height, so lay the component out to fill it (`height: 100%`) and let long content scroll inside. Form field kinds: `text`, `textarea`, `number`, `select`, `toggle`, `segmented`, `color-token`, `array`, `group`. Bump `version` and add `migrate(data, from)` when you change the data shape; `migrate(doc, { registry })` runs it on stored widgets whose `version` is older.

Built-ins, with each type's data, default size (w×h) and min..max:

| Type | Data | Default | Min | Max |
| --- | --- | --- | --- | --- |
| `heading` | `level?` 1–3, `description?` | 12×1 | 3×1 | 12×3 |
| `kpi` | `sparkStyle` `line` \| `bar`, `goal?`, `description?` | 3×3 | 2×3 | 6×4 |
| `kpi-strip` | none | 12×3 | 8×3 | 12×4 |
| `text` | `markdown` | 6×3 | 3×2 | 12×12 |
| `briefing` | `focus?` | 6×5 | 4×4 | 12×10 |
| `trend` | `chart` `area` \| `line` \| `bar`, `showPrevious` | 6×6 | 4×4 | 12×12 |
| `chart` | `chart` `bar` \| `line` \| `area` \| `donut`, `orientation`, `stacked` | 6×6 | 4×4 | 12×12 |
| `funnel` | `showPercentOfFirst`, `showPercentOfPrevious` | 6×6 | 4×4 | 12×10 |
| `leaderboard` | `showChange`, `showRank` | 6×6 | 3×4 | 12×12 |
| `table` | `totals`, `dense` | 12×6 | 6×4 | 12×16 |

- **`kpi`**: label (with an info tooltip when `description` is set), a large value, a change badge against the previous period (coloured by polarity; "—" when there is no previous period), an automatic sparkline from `frame.spark`, and with `goal` a progress line ("On track" or "Behind", judged from the elapsed share of the window; for a lower-is-better metric staying under the goal is on track). Long counts and sums print compactly (`$4.56M`).
- **`kpi-strip`**: 2–4 tiles in the same anatomy, without sparklines.
- **`trend`**: area, line or bars over the frame's time rows; up to four metrics, or one metric split into top-N client lines (the legend shows from two series); a dashed previous-period overlay with one metric and no split.
- **`chart`**: bars (vertical or horizontal, grouped or stacked), lines or areas across the rows of `by`; a donut for one additive metric, with the total in the centre and a legend with values and shares (more than four slices fold into a neutral "Other").
- **`funnel`**: S-curve bands, one per step, with each step's value and its share of the first and of the previous step; a missing value shows "—"; fewer than two steps shows "Add at least 2 steps".
- **`leaderboard`**: ranked bars for metric 0, up to two extra metric columns and a change badge (`showChange` needs `compare: 'previous'`). It ranks by metric 0, biggest first, unless the query sorts, and shows 10 rows unless the query limits. The extra columns give way when the card is too narrow for them.
- **`table`**: a column per metric after a sticky label column (dates when `over` is set); a sticky header, click-to-sort headers, an optional totals row from `frame.totals`, and horizontal scroll beyond the card width.
- **`briefing`**: see [Briefing](#briefing).

The `slots` of 0.3 are gone: a widget has one `query`. The visuals are Bytes' shadcn/ui (new-york) source, copied into `src/react/ui/` and recoloured with the `--dk-*` tokens: shadcn primitives on Radix, charts on Recharts 2.15, tables on TanStack Table v8. Licence and provenance notes are in `src/react/ui/shadcn/LICENSE-NOTES.md`. dashkit does not use Tailwind's palette; every colour in the widgets comes from a `--dk-*` token.

## AI

`dashkit/ai` has no provider SDK and no network code. It gives you four tools, an executor and prompt text:

| Tool | Does |
| --- | --- |
| `dashboard_describe` | Returns `summarize(doc)`: one line per widget with its id, type, title, size and position, and under it the whole query |
| `dashboard_apply` | Applies a list of ops (every op except `replaceDashboard`), including `setQuery` and `clearQuery` |
| `dashboard_propose_widget` | Adds one widget: `{ type, title?, size?, after?, query?, data? }`; the id is generated |
| `catalog_search` | Finds metrics and dimensions by key, label or description |

```ts
import { applyToolCall, systemPromptFragment, toolDefinitions } from 'dashkit/ai';
import type { Catalog, Dashboard, Registry } from 'dashkit/core';

declare const registry: Registry, catalog: Catalog;

const openaiTools = toolDefinitions({ registry, catalog, style: 'openai' }); // { type: 'function', function: { name, description, parameters } }
const anthropicTools = toolDefinitions({ registry, catalog, style: 'anthropic' }); // { name, description, input_schema }
const neutralTools = toolDefinitions({ registry, catalog, style: 'json-schema' }); // { name, description, parameters, 'x-dashkit-widgets'? }

const system = `You are the analytics assistant.\n\n${systemPromptFragment({ registry, catalog })}`;

// For each tool call the model makes:
export function runTool(doc: Dashboard, name: string, args: unknown) {
  const result = applyToolCall(doc, { name, args }, { registry, catalog }); // args may be the raw JSON string
  if (result.ok) return { doc: result.doc, reply: { ok: true, diff: result.diff, result: result.result } };
  return { doc, reply: result }; // { ok: false, error: { code, path, message } }: send it back so the model retries
}
```

Tool schemas are narrowed to your catalog (metric, dimension and window enums) and registry (widget types), so regenerate them when either changes.

`applyToolCall(doc, call, { registry, catalog, author? })` never throws for bad input and never mutates `doc`:

- `{ ok: true, doc, diff, result }`: the new document, human-readable change lines (`diff`), and the tool's own result (the outline for describe, `{ applied }` for apply, `{ widgetId }` for propose, matches for search).
- `{ ok: false, error: { code, path, message } }`: nothing changed.

Only new validation errors reject a call. Errors already present in `doc` (say, a metric that has since left the catalog) do not block other edits, so a model can repair a broken dashboard one step at a time. Errors are matched by the widget id they belong to (paths are rewritten from `widgets.<i>…` to `widget:<id>…`), so moving widgets around does not make an old error look new. Replacing one bad value with another bad value counts as new.

`systemPromptFragment({ registry, catalog })` is markdown to append to your system prompt: tool rules, each widget type with its `aiHint` and default, min and max size, a table of each type's query rules, metrics with format, unit and polarity (`[currency, USD, lower is better]`) and whether they can be shown `over time` or are `not additive`, dimensions, windows, grid rules (12 columns of 48px rows, headings as sections, `after` placement, never pixels or CSS) and worked examples, including moving and resizing. It is deterministic, so it caches well.

`generateFromBrief(brief, llm, { registry, catalog, title?, maxRounds?, style? })` builds a new dashboard from a sentence by looping your model over the tools (default 6 rounds, stops when a round makes no tool calls). You supply the model call:

```ts
import { generateFromBrief, type LlmFn } from 'dashkit/ai';
import type { Catalog, Registry } from 'dashkit/core';

declare const registry: Registry, catalog: Catalog;
declare function callModel(req: { system: string; messages: unknown[]; tools: unknown[] }): Promise<{ text?: string; toolCalls?: { id: string; name: string; args: unknown }[] }>;

const llm: LlmFn = async ({ system, messages, tools }) => callModel({ system, messages, tools }); // map to and from your provider here

const { doc, transcript } = await generateFromBrief('spend and leads by client, trend of spend', llm, { registry, catalog });
```

`messages` use roles `user`, `assistant` (with `toolCalls`) and `tool` (with `toolCallId`, content is the JSON result).

`summarize(doc)` (what `dashboard_describe` returns) looks like this:

```text
# Weekly spend (3 widgets)
- [h-weekly-spend] heading "Weekly spend" 12×2 @0,0 (h1)
- [k-spend] kpi "Spend" 3×3 @0,2
    query: metrics=spend window=last_30d compare spark
- [w-leads-trend] trend "Leads by day" 8×7 @0,5
    query: metrics=leads by=client over=day window=last_30d limit=4
```

The `query:` line (indented four spaces) prints the whole query, so a model that replaces it with `setQuery` never erases what it could not see: `metrics=<m>[,<m>…][ by=<d>][ over=<g>] window=<preset|from..to>[ compare][ spark| nospark][ sort=<metric>:<dir>][ limit=<N>][ filters=<dim>:<v1>|<v2>[;<dim>:…]]`, where `<m>` is the metric key, or `key:"Label"` (a JSON string) when it has a label. Filter dimensions are sorted. `nospark` marks an explicit `spark: false` (a kpi query with no `spark` field sparks by default), so the opt-out survives a `setQuery`.

### Non-JS backends

When your agent runs in Python (or anything else), keep one applier: the frontend. The backend only proposes ops.

1. **Export the tool definitions** with a small Node script and check the output into the backend. `json-schema` style is provider-neutral; `x-dashkit-widgets` on `dashboard_propose_widget` lists the widget types with their sizes, `queryRules` (the plain-data parts of each type's query rules) and form `fields` (key, label, kind, options) for hosts that build their own prompt or mirror the rules. Strip it before sending the definition to a provider.

   ```ts
   // scripts/export-dashkit-tools.ts (run with tsx after the catalog or widgets change)
   import { writeFileSync } from 'node:fs';
   import { systemPromptFragment, toolDefinitions } from 'dashkit/ai';
   import { builtinWidgets, createRegistry } from 'dashkit/react';
   import { catalog } from './catalog';

   const registry = createRegistry(builtinWidgets);
   writeFileSync('backend/dashkit/tools.json', JSON.stringify(toolDefinitions({ registry, catalog, style: 'json-schema' }), null, 2));
   writeFileSync('backend/dashkit/prompt.md', systemPromptFragment({ registry, catalog }));
   writeFileSync('backend/dashkit/catalog.json', JSON.stringify(catalog, null, 2)); // functions (dimension values) are dropped
   ```

2. **Register them in your agent.** Executors validate the arguments against the schema and return ops; they never touch the stored document. `dashboard_describe` answers from the summary the frontend sends with the chat request (step 3), so it reflects the dashboard as it was when the turn started, not ops queued earlier in the same turn.

   ```python
   TOOLS = json.load(open("dashkit/tools.json"))
   CATALOG = json.load(open("dashkit/catalog.json"))
   SCHEMAS = {t["name"]: t["parameters"] for t in TOOLS}

   def dashboard_describe(args, ctx):
       return {"ok": True, "result": ctx.request.summary}  # summarize(doc) from the frontend

   def dashboard_apply(args, ctx):
       jsonschema.validate(args, SCHEMAS["dashboard_apply"])
       ctx.dashboard_ops.extend(args["ops"])
       return {"ok": True, "result": {"applied": len(args["ops"])}}

   def dashboard_propose_widget(args, ctx):
       jsonschema.validate(args, SCHEMAS["dashboard_propose_widget"])
       widget_id = secrets.token_hex(6)
       widget = {"id": widget_id, "type": args["type"]}
       widget.update({k: args[k] for k in ("title", "size", "query", "data") if k in args})
       op = {"op": "addWidget", "widget": widget}
       if "after" in args:  # right of that widget if it fits, else the row below; absent: a new row at the bottom
           op["after"] = args["after"]
       ctx.dashboard_ops.append(op)
       return {"ok": True, "result": {"widgetId": widget_id}}

   def catalog_search(args, ctx):
       jsonschema.validate(args, SCHEMAS["catalog_search"])
       q = args["query"].strip().lower()
       hit = lambda item: any(q in (item.get(f) or "").lower() for f in ("key", "label", "description"))
       return {"ok": True, "result": {
           "metrics": [m for m in CATALOG["metrics"] if hit(m)][:20],
           "dimensions": [{"key": d["key"], "label": d["label"]} for d in CATALOG["dimensions"] if hit(d)],
           "windows": CATALOG["windows"],
       }}

   EXECUTORS = {"dashboard_describe": dashboard_describe, "dashboard_apply": dashboard_apply,
                "dashboard_propose_widget": dashboard_propose_widget, "catalog_search": catalog_search}
   for t in TOOLS:
       agent.register_tool(name=t["name"], description=t["description"], parameters=t["parameters"], executor=EXECUTORS[t["name"]])

   # ... return ChatResponse(reply=text, dashboard_ops=ctx.dashboard_ops)
   ```

   Append `prompt.md` to the system prompt when the user is on a dashboard page.

3. **Send the summary, apply the ops on the frontend** through the editor so the change lands in its history, then save. Running `applyToolCall` first gives you the same "new errors only" check and the `diff` lines to show in the chat:

   ```ts
   import { applyToolCall } from 'dashkit/ai';
   import { summarize, type Catalog, type Op, type Registry } from 'dashkit/core';
   import type { Store } from 'dashkit/adapters';
   import type { DashboardEditorApi } from 'dashkit/react';

   declare function postChat(body: { message: string; dashboard_id: string; summary: string }): Promise<{ reply: string; dashboard_ops?: Op[] }>;

   export async function askAssistant(message: string, api: DashboardEditorApi, store: Store, ctx: { registry: Registry; catalog: Catalog }) {
     const doc = api.getDoc();
     const res = await postChat({ message, dashboard_id: doc.id, summary: summarize(doc) });
     const ops = res.dashboard_ops ?? [];
     if (ops.length === 0) return { reply: res.reply, diff: [] as string[] };
     const check = applyToolCall(api.getDoc(), { name: 'dashboard_apply', args: { ops } }, ctx);
     if (!check.ok) return { reply: res.reply, error: check.error.message }; // tell the user (and the model, next turn)
     const before = api.getDoc();
     const next = api.applyAll(ops, 'ai'); // one undo step
     if (next === before) return { reply: res.reply, error: 'rejected by the editor' }; // reason shown in the toolbar
     await store.save(next);
     api.markSaved();
     return { reply: res.reply, diff: check.diff };
   }
   ```

## Playground

`playground/` is a Next.js app that runs the kit with the mock data source, a stubbed `BriefingProvider` (a canned briefing after a short delay) and a keyword-based fake model: editor, renderer, "Generate from brief" and a chat panel that applies `addWidget` and `setQuery` ops through `apiRef.applyAll` ("change Leads by day to last 7 days"). Its sample board, "Weekly spend", uses every built-in type: a level-1 heading, four KPIs (a goal, line and bar sparklines), a KPI strip, a trend over day with a line per client beside a briefing, a bar chart, a donut, a four-step funnel, a leaderboard with two extra columns and a change badge, an eight-column table with totals and a note. From the repo root: `npm install && npm run playground` (port 3100). See `playground/README.md` for URL parameters.

![Playground, view mode](docs/screenshots/playground-v3-view.png)
![Playground, edit mode with the funnel's steps in the query builder](docs/screenshots/playground-v3-edit.png)
![Playground, dark](docs/screenshots/playground-v3-dark.png)

## Upgrading from 0.3

- **Documents.** Run `migrate(doc, { registry, catalog })` on every document you load. A stored v2 document becomes v3 in memory (each widget's bindings become one `query`; see `CHANGELOG.md` for what becomes what) and the next save stores v3, so no bulk migration is needed. Pass `catalog` so a donut on a ratio and a chart that mixes formats become documents that still validate.
- **Data source.** Replace `resolve(bindings, shapes)` with `query(queries) → (Frame | null)[]`. `createFetchDataSource` now posts `{ queries }` to `{base}/dashboards/query` and reads `{ frames }`; the route has to compute daily and previous-period data for every metric the catalog marks `over: true`. Mark those metrics in the catalog (`over` defaults to false) and flag ratios `additive: false`.
- **Backend validation.** Re-sync `dashkit/schema.json` (`$id` is now `…/dashboard-v3.json`, and `version` is the literal `3`) and the exported tool definitions and prompt. During the rollout accept v2 on save, validated against a frozen v2 schema, and deploy the backend before the frontend (as in 0.3).
- **Briefing.** `BriefingContext` and `onAsk` are gone. Provide a `BriefingProvider` with `onBriefing(req) → Promise<BriefingResult>` and a briefing endpoint (see [Briefing](#briefing)); without one the widget says "Briefings need a host connection".
- **Ops and AI.** Code that builds ops moves `bindings` to `query` and uses `setQuery`. `dashboard_propose_widget` takes `query`, not `bindings`. The summary line adds a `query:` line.
- **Removed types.** `bar`, `donut` and `comparison` are now `chart`; a host's own custom types lose any v2 `bindings` on load (they have no query), so port them to a `query` rule.
- **Components.** `components.Select` and `Menu` are no longer rendered, and the editor's panel ignores `Button` and `Input` (the toolbar still uses them).
- **Theme.** Add `--dk-chart-6..8` to a host theme that maps `--dk-chart-1..5`. Hosts with their own `@keyframes enter`, `exit`, `spin` or `pulse` read the host notes under [Theme](#theme).
- **Dependencies.** `tailwind-variants` and `@radix-ui/react-slot` are dropped; `radix-ui`, `@tanstack/react-table`, `cmdk`, `lucide-react` and `class-variance-authority` are added (installed with dashkit).

## Upgrading from 0.2

- Run `migrate(doc, { registry })` on every document you load. Stored v1 documents (sections and spans) become v2 (headings and positioned widgets) in memory; the next save stores v2, so no bulk migration is needed.
- If your backend validates saved documents, deploy it first accepting both v1 and v2 (v1 against the 0.2 schema), then the frontend; re-tighten to v2 only once no 0.2 tabs remain (see `CHANGELOG.md`, Upgrading).
- Backends that validate with `dashkit/schema.json` or the exported tool definitions must re-sync both (the schema `$id` is now `…/dashboard-v2.json`). Code that builds ops must drop `sectionId`, `span` and the section ops; see `CHANGELOG.md`.
- Remove `@dnd-kit/core` and `@dnd-kit/sortable` if nothing else uses them. On React 19.2+, add the `react-is` override (see [Install](#install)).
- Replace styles that targeted the old class names (`.dk-widget`, `.dk-section`, …) with `--dk-*` overrides. `header="hero"` is gone: add a level-1 `heading` widget.

## Versioning and limits

- `0.x`: breaking changes can land in minor versions; see `CHANGELOG.md`.
- Peers: React and React DOM 19, recharts `^2.15` (with `react-is` overridden to your React version on 19.2+), zod `>=3.25 <4`; vitest 3+ only for the contract suites. Node 22 or newer (`engines`). ESM only.
- Documents carry `version: 3`. `migrate(doc, { registry, catalog? })` upgrades older documents and per-widget data, and clamps widget sizes into their type's range (re-normalizing only when one was out of range); it is a no-op on current, in-range documents. `dashkit/schema.json` is the dashboard document as JSON Schema (draft 2020-12, `$id` `https://dashkit.dev/schema/dashboard-v3.json`), for validating documents in other languages, e.g. before a backend writes one.
- Layout: `x` 0–11, `y` 0–999, `w` 1–12, `h` 1–24, `x + w <= 12` (else `LAYOUT_OUT_OF_BOUNDS`); sizes must also fit the widget type's `minSize`..`maxSize` (else `SIZE_OUT_OF_RANGE`). Locked widgets cannot be moved or resized (`WIDGET_LOCKED`) but are pushed down by others.
- OpenAI `strict: true` structured outputs reject the tool schemas (optional properties and `anyOf`); register the tools with default function calling.
- `styles.css` uses CSS container queries and `color-mix()`, so it targets evergreen browsers.
- The schema checks structure only. Widget data, queries (against their type's rules and the catalog) and sizes are checked by `validate(doc, { registry, catalog })`, which needs the registry, so do it in JS.
